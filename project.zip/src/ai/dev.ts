import { config } from 'dotenv';
config();

import '@/ai/flows/cyber-attack-summarizer.ts';
import '@/ai/flows/cyber-law-chatbot.ts';